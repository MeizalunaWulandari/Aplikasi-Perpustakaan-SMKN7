
<?php $__env->startSection('content'); ?>
    <div class="page-heading">
        <h3>Kurikulum Buku</h3><br><br>
        <div>
            <a href="<?php echo e(url('admin/tambah-kurikulum')); ?>" class="btn btn-primary">Add</a>
            
            <div class="d-sm-inline-block">
                <div class="form-group">
                    <label for="filter">Filter </label>
                    <select name="filter_katkur" id="filter" class="form-control" required>
                        <option value="">Filter</option>
                        <option value="1">Kategori</option>
                        <option value="2">Kurikulum</option>
                    </select>
                </div>
            </div>
        </div><br><br>
        <div class="modal fade" id="exampleModalCenter" tabindex="-1" role="dialog"
            aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered modal-dialog-centered modal-dialog-scrollable" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalCenterTitle">Vertically Centered
                        </h5>
                        <button type="button" class="close" data-bs-dismiss="modal" aria-label="Close">
                            <i data-feather="x"></i>
                        </button>
                    </div>
                    <form action="" method="post">
                        <div class="modal-body">
                            <div class="form-group">
                                <label for="nama-kategori">Nama Kategori</label>
                                <input type="text" id="nama-kategori" class="form-control" name="nama_kategori">
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-light-secondary" data-bs-dismiss="modal">
                                <i class="bx bx-x d-block d-sm-none"></i>
                                <span class="d-none d-sm-block">Close</span>
                            </button>
                            <button type="button" class="btn btn-primary ml-1" data-bs-dismiss="modal">
                                <i class="bx bx-check d-block d-sm-none"></i>
                                <span class="d-none d-sm-block">Save</span>
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <div class="page-body">
        <div class="datatable">
            <table id="table-kurikulum" class="table table-striped" style="width:100%">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Nama Kurikulum</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                
                <tfoot>
                    <tr>
                        <th>No</th>
                        <th>Nama Kurikulum</th>
                        <th>Aksi</th>
                    </tr>
                </tfoot>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script>
        const table = $('#table-kurikulum').DataTable({
            dom: '<lf<t>ip>',
            // pageLength: 10,
            // bLengthChange: false,
            processing: true,
            serverSide: true,
            ajax: {
                url: "<?php echo e(route('api.admin.kurikulum')); ?>",
                data: function(d) {
                    d.katkur = $('select[name=filter_katkur]').val();
                }
            },
            columns: [{
                    data: 'DT_RowIndex',
                    name: 'DT_RowIndex'
                },
                {
                    data: 'name',
                    name: 'name'
                },
                // {
                //     data: 'type',
                //     name: 'type'
                // },
                {
                    className: 'actions-control',
                    data: 'null',
                    defaultContent: '<a href="/admin/tambah-detail-buku/2" class="btn btn-primary"><i class="bi bi-file-earmark-plus"></i></a> <a href="/admin/edit-buku/2" class="btn btn-primary"><i class="bi bi-pencil-square"></i></a>'
                }
            ],
            columnDefs: [{
                render: function(data, type, row, meta) {

                    const html =
                        `<a href="/admin/edit-jenis-buku/${row.id}" class="btn btn-primary"><i class="bi bi-pencil-square"></i></a>` +
                        `<button class="btn btn-danger hapus-jenis-buku" data-id="${row.id}" data-keterangan="${row.keterangan}"><i class="bi bi-trash3"></i></button>`;

                    return html;
                },
                targets: [2]
            }, ],
            order: [],
            language: {
                search: "",
                searchPlaceholder: "Search"
            }
        });

        $('#filter').change(function() {
            table.draw();
        });

        $('#table-kurikulum tbody').on('click', 'td button.hapus-jenis-buku ', function() {
            // console.log($(this).attr("data-judul"));
            const keterangan = $(this).attr("data-keterangan");
            if (confirm(`Yakin ingin menghapus jenis buku ${keterangan} ?`) == true) {

                const id = $(this).attr("data-id");

                $.ajax({
                    type: "POST",
                    url: "<?php echo e(url('/admin/hapus-jenis-buku')); ?>/" + id,
                    data: {
                        _token: "<?php echo e(csrf_token()); ?>",
                        _method: 'DELETE',
                    },
                    success: function(data) {
                        table.draw()
                    }
                });

            }
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.template_admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\SMK7-E-Library\resources\views/admin/kurikulum.blade.php ENDPATH**/ ?>