

<?php $__env->startSection('content'); ?>
    <section>
        <div class="container detail">
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>">Beranda</a></li>
                    <li class="breadcrumb-item"><a href="<?php echo e(url('katalog')); ?>">Katalog</a></li>
                    <li class="breadcrumb-item"><a
                            href="<?php echo e(url('katalog/' . $buku->slug_kategori)); ?>"><?php echo e($buku->nama_kategori); ?></a></li>
                    <li class="breadcrumb-item active" aria-current="page"><?php echo e($buku->judul); ?></li>
                </ol>
            </nav>
            <div class="detail-wrapper">
                <div class="detail-card">
                    <div class="detail-img" id="detail-img">
                        <img src="<?php echo e(asset('storage/' . $buku->cover)); ?>" alt="">
                    </div>

                    <div class="detail-info mt-3">
                        <div class="detail-header">
                            <h5 class="title"><?php echo e($buku->judul); ?></h5>
                            <p class="muted"><?php echo e($buku->jenis_buku); ?></p>
                            <?php if($buku->jenis_buku != 'Fisik'): ?>
                                <a href="<?php echo e(url('download-ebook/' . $buku->id_buku)); ?>">
                                    <button class="btn btn-primary">
                                        <i class="bi bi-file-earmark-arrow-down"></i> Download
                                    </button>
                                </a>
                                <button class="btn btn-outline-primary" data-bs-toggle="modal"
                                    data-bs-target="#read-book"><i class="bi bi-book"></i> Baca Online</button>
                                <!-- Modal -->
                                <div class="modal fade" id="read-book" tabindex="-1" aria-labelledby="exampleModalLabel"
                                    aria-hidden="true">
                                    <div class="modal-dialog modal-xl modal-dialog-center">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h5 class="modal-title" id="exampleModalLabel">
                                                    <?php echo e($buku->judul); ?>

                                                </h5>
                                                <button type="button" class="btn-close" data-bs-dismiss="modal"
                                                    aria-label="Close"></button>
                                            </div>
                                            <div class="modal-body ">
                                                <object data="<?php echo e(asset('storage/buku-digital/' . $buku->file_pdf)); ?>"
                                                    type="application/pdf" style="width: 100%; height: 80vh;">
                                                    <embed src="<?php echo e(asset('storage/buku-digital/' . $buku->file_pdf)); ?>"
                                                        type="application/pdf">
                                                </object>
                                                <div class="pdfjs-viewer">
                                                    <div class="viewer">

                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            <?php else: ?>
                                <?php if(Auth::guard('websiswa')->check() == false): ?>
                                    <a href="<?php echo e(url('login')); ?>">
                                        <button class="btn btn-primary mt-3">Masuk Untuk Meminjam buku</button>
                                    </a>
                                <?php else: ?>
                                    <a href="#">
                                        <button class="btn btn-outline-primary mt-3" data-bs-toggle="modal"
                                            data-bs-target="#notelp"><i class="bi bi-file-earmark-plus"></i>
                                            Pinjam Buku</button>
                                    </a>
                                    <div class="modal fade" id="notelp" tabindex="-1"
                                        aria-labelledby="exampleModalLabel" aria-hidden="true">
                                        <div class="modal-dialog">
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <h5 class="modal-title" id="exampleModalLabel">Masukkan Nomor Telepon
                                                    </h5>
                                                    <button type="button" class="btn-close" data-bs-dismiss="modal"
                                                        aria-label="Close"></button>
                                                </div>
                                                <div class="modal-body">
                                                    <form action="<?php echo e(url('booking')); ?>" method="post">
                                                        <?php echo csrf_field(); ?>
                                                        <div class="mb-3">
                                                            <label for="exampleFormControlInput1" class="form-label">Nomor
                                                                Telepon</label>
                                                            <input type="number" class="form-control"
                                                                id="exampleFormControlInput1" placeholder="628**********"
                                                                name="notelp" value="628">
                                                        </div>
                                                    </form>
                                                    <button type="button" class="btn btn-primary">Booking Now</button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <p class="muted mt-3">Availble Stock <b><?php echo e($buku->stock); ?></b></p>
                                <?php endif; ?>
                            <?php endif; ?>
                            <!-- Modal -->
                        </div>

                        <p class="muted">Telah dibaca 1.000 kali</p>

                        <div class="row align-items-center mb3">
                            <div class="col-6 col-lg-2">
                                <span>Detail Buku</span>
                            </div>
                            <div class="col-6 col-lg-2">
                                <hr>
                            </div>
                        </div>
                        <?php if($buku->jenis_buku != 'Fisik'): ?>
                            <div class="row pdf-statistic mt-3">
                                <div class="col-lg-3">
                                    <p>Penerbit</p>
                                    <p><?php echo e($buku->penerbit); ?></p>
                                </div>
                                <div class="col-lg-3">
                                    <p>Penulis</p>
                                    <p><?php echo e($buku->pengarang); ?></p>
                                </div>
                                <div class="col-lg-3">
                                    <p>Tahun Buku</p>
                                    <p><?php echo e($buku->tahun_buku); ?></p>
                                </div>
                                <div class="col-lg-3">
                                    <p>ISBN</p>
                                    <p><?php echo e($buku->isbn); ?></p>
                                </div>
                            </div>
                        <?php else: ?>
                            <div class="row pdf-statistic mt-3">
                                <div class="col-lg-3">
                                    <p>Penerbit</p>
                                    <p><?php echo e($buku->penerbit); ?></p>
                                </div>
                                <div class="col-lg-3">
                                    <p>Pengarang</p>
                                    <p><?php echo e($buku->pengarang); ?></p>
                                </div>
                                <div class="col-lg-3">
                                    <p>Edisi</p>
                                    <p><?php echo e($buku->tahun_buku); ?></p>
                                </div>
                                <div class="col-lg-3">
                                    <p>Tahun Terbit</p>
                                    <p><?php echo e($buku->tahun_terbit); ?></p>
                                </div>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        <?php $__env->stopSection(); ?>

        <?php $__env->startSection('script'); ?>
            <script>
                var pdfViewer = new PDFjsViewer($('.viewer'));
                pdfViewer.loadDocument('<?php echo e(asset('storage/buku-digital/' . $buku->file_pdf)); ?>');
                var pdfjsLib = window['pdfjs-dist/build/pdf'];
                pdfjsLib.GlobalWorkerOptions.workerSrc = 'https://cdnjs.cloudflare.com/ajax/libs/pdf.js/2.11.338/pdf.worker.min.js';
            </script>
        <?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.template_siswa', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\SMK7-E-Library\resources\views/siswa/detail.blade.php ENDPATH**/ ?>