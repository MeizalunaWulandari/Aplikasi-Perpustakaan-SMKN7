
<?php $__env->startSection('content'); ?>
<div class="page-heading">
    <h3>Data Booking</h3><br><br>
    <div class="d-sm-flex align-items-center justify-content-end">
        <div class="d-sm-inline-block">
            <a href="#" class="btn btn-primary">Export</a>
        </div>
    </div><br><br>
    <div class="datatable">
        <table id="example" class="table table-striped" style="width:100%">
            <thead>
                <tr>
                    <th>No</th>
                    <th>NISN Peminjam Buku</th>
                    <th>Nama Peminjam Buku</th>
                    <th>Nomor Telpon Peminjam</th>
                    <th>Judul Buku</th>
                    <th>Verifikasi</th>
                </tr>
            </thead>
            <tbody>
                <?php $no = 1; ?>
                <?php $__currentLoopData = $booking; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($no++); ?></td>
                    <td><?php echo e($item->nisn); ?></td>
                    <td><?php echo e($item->nama); ?></td>
                    <td><a href="https://wa.me/<?php echo e($item->notelp); ?>" target="_break" title="Hubungi <?php echo e($item->nama); ?>"><?php echo e($item->notelp); ?></a></td>
                    <td><?php echo e($item->buku_id); ?></td>
                    <td>
                        <form action="#" method="post">
                            <?php echo csrf_field(); ?>
                            <button type="submit" class="status red <?php echo e($item->status == '1' ? 'active' : ''); ?>" value="1" name="status" data-bs-toggle="tooltip" data-bs-placement="top" title="Set status to : Unverified"></button>
                            <button type="submit" class="status green <?php echo e($item->status == '2' ? 'active' : ''); ?>" value="2" name="status" data-bs-toggle="tooltip" data-bs-placement="top" title="Set status to : Verified"></button>
                        </form>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
            <tfoot>
                <tr>
                    <th>No</th>
                    <th>NISN Peminjam Buku</th>
                    <th>Nama Peminjam Buku</th>
                    <th>Nomor Telpon Peminjam</th>
                    <th>Judul Buku</th>
                    <th>Verifikasi</th>
                </tr>
            </tfoot>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.template_admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\SMK7-E-Library\resources\views/admin/databookingduedate.blade.php ENDPATH**/ ?>