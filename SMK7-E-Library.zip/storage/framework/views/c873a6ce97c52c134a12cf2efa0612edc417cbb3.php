


<?php $__env->startSection('content'); ?>
<?php $__env->startSection('user'); ?>
    <div class="card">
        <div class="card-header">
            <h5 class="card-title">Profile</h5>
        </div>
        <div class="card-body">
            <div class="mb-3">
                <label for="exampleFormControlInput1" class="form-label">Name</label>
                <input type="text" class="form-control" id="exampleFormControlInput1" placeholder="Your Name" readonly
                    value="<?php echo e(Auth::guard('websiswa')->user()->nama); ?>">
            </div>
            <div class="mb-3">
                <label for="exampleFormControlInput1" class="form-label">Username</label>
                <input type="text" class="form-control" id="exampleFormControlInput1" placeholder="Your Username"
                    readonly value="<?php echo e(Auth::guard('websiswa')->user()->username); ?>">
            </div>
            <div class="mb-3">
                <label for="exampleFormControlInput1" class="form-label">Phone Number</label>
                <input type="number" class="form-control" id="exampleFormControlInput1" placeholder="+628**********"
                    value="<?php echo e(Auth::guard('websiswa')->user()->phone_number); ?>">
            </div>
            <button type="submit" class="btn btn-primary">Save</button>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.template_userpage', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layout.template_siswa', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\SMK7-E-Library\resources\views/siswa/user/profile.blade.php ENDPATH**/ ?>