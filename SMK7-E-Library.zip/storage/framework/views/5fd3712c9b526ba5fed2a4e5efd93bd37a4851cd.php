<section>
    <div class="container" id="user">
        <div class="row">
            <div class="col-4">
                <div class="card">
                    <div class="card-header">
                        <h5 class="card-title">Dashboard</h5>
                    </div>
                    <div class="card-body user-navigation">
                        <ul>
                            <li><a href="<?php echo e(url('user/profile')); ?>" class="link"><i class="bi bi-person"></i> Profile</a></li>
                            <li><a href="<?php echo e(url('user/history')); ?>" class="link"><i class="bi bi-clock-history"></i> History</a></li>
                            <li><a href="<?php echo e(url('logout')); ?>" class="link"><i class="bi bi-box-arrow-left"></i> Logout</a></li>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="col-lg">
                <?php echo $__env->yieldContent('user'); ?>
            </div>
        </div>
    </div>
</section><?php /**PATH C:\laragon\www\SMK7-E-Library\resources\views/layout/template_userpage.blade.php ENDPATH**/ ?>