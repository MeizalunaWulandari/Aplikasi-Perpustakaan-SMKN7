

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-4">
                <div class="card">Awikwok</div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.template_siswa', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\SMK7-E-Library\resources\views/siswa/profil.blade.php ENDPATH**/ ?>